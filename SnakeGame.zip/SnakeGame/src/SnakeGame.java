import javax.swing.JFrame;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;

public class SnakeGame extends JFrame {

    public SnakeGame() {
        // 設定視窗標題
        this.setTitle("Auto SnakeGame");
        // 設定視窗大小 改為外部設定
//        this.setSize(800, 600);
        // 設定關閉視窗時的行為
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // 移除視窗標題和邊框，讓它變為全螢幕
        this.setUndecorated(true);
        // 設定為最大化，填滿整個螢幕
        this.setExtendedState(JFrame.MAXIMIZED_BOTH);
//        // 讓視窗顯示在螢幕中央
        this.setLocationRelativeTo(null);
//        // 設定視窗不可變更大小
//        this.setResizable(false);

        // 建立並新增 GamePanel
        GamePanel gamePanel = new GamePanel();
        this.add(gamePanel);
        // 使用 pack() 方法讓視窗大小適應面板
//        this.pack(); // 移除 this.pack()，因為視窗已經最大化了
        // 顯示視窗
        this.setVisible(true);

        // 讓視窗進入全螢幕模式
//        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
//        GraphicsDevice gd = ge.getDefaultScreenDevice();
//        gd.setFullScreenWindow(this);
    }

    public static void main(String[] args) {
        // 使用 SwingUtilities.invokeLater 確保 GUI 在正確的線程上啟動
        javax.swing.SwingUtilities.invokeLater(() -> new SnakeGame());
    }
}